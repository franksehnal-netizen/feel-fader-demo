# Click It! for Feel Fader

Click any parameter in Ableton Live, then turn the Feel Fader roller to move it. Store up to nine parameters
in slots and switch the roller between them with controller buttons. Works while recording (Live writes
automation) and while mixing. Requires Ableton Live 12.

## What's in the package

- `FeelFader_ClickIt/` – the Live control surface script that does the work.
- `Click It!.amxd` – Max for Live device with the display, the slot buttons and the
  settings (needs Live Suite or Max for Live). Click It! works without it, slots need it.
- This guide.

## Install

1. Quit Live.
2. Copy the folder `FeelFader_ClickIt` into your User Library's `Remote Scripts` folder:
   - Windows: `Documents\Ableton\User Library\Remote Scripts\`
   - macOS: `Music/Ableton/User Library/Remote Scripts/`

   Create the `Remote Scripts` folder if it does not exist. Updating from Last Click (the previous name): delete the folder `FeelFader_LastClick` first.
3. Start Live. Open **Settings → Link, Tempo & MIDI**. In a free Control Surface row choose
   **FeelFader ClickIt**, set **Input** to **Feel Fader** and **Output** to **None**.
4. In the Feel Fader app, set the roller of the bank you use to **Relative CC**, MIDI channel **1**, CC **102**.
5. Drop `Click It!.amxd` on the **Main** track (one per set). In sets made with Last Click,
   replace the old LAST CLICK device with this one.

After step 3, Live shows the Feel Fader input as "FeelFader_ClickIt Input (Feel Fader)" in track input
menus. That is only a new label – tracks that used the Feel Fader input keep it.

The script sends what the device shows over the computer's internal network connection (127.0.0.1, port
47816); nothing leaves your computer. If your firewall asks whether Live may use the network, allowing it
for private networks is enough.

## The device at a glance

The script does the work: it knows what you clicked, takes the roller, moves the value and remembers the
slots. The Click It! device is only the display and the buttons. Outside Click It! the roller's CC goes to
your tracks as usual (for example as keyswitches) – Click It! borrows the roller for a moment, or for as
long as you want.

**Display**

| Part | Shows |
|---|---|
| Roller (left) | dark = nothing taken · red, slowly fading = the window after a click is running · red, steady = HOLD or a slot 2–10. It turns as you turn yours, and the window edge on the turning side lights up. |
| Slot strip LC, 2–10 (ADV) | red = active slot · light = stored · dark = empty. In WRITE mode slots 2–10 blink. |
| Text (right) | parameter name, device (track name for mixer controls), value in red. `click a parameter` when idle. Without ADV a slot 2–10 that holds the roller shows as a number before the name. |
| `Script off` | the device gets nothing from the script; it shows where to switch it on (Settings › Link, Tempo & MIDI › Control Surface). |

**Controls**

| Control | What it does | Default |
|---|---|---|
| On/off (device title bar) | Switches Click It! on and off. | on |
| **HOLD** | Off: the roller lets go after **Time** from your last turn. On: it stays on the clicked parameter. LC only – dimmed while a slot 2–10 is active. | off |
| **Time** (next to HOLD) | How long the roller stays on the clicked parameter after your last turn, 0.5–10 s. After a click you always get at least 3 s to start turning. Dimmed with HOLD on or a slot 2–10 active – they have no time limit. | 2.0 s |
| **ACC** | Turning fast moves a parameter by bigger steps, turning slowly by exactly one step. | on |
| **S** | Roller steps across a parameter's full range, 1024 (fine) to 16 (coarse). | 128 |
| **CC** | The roller's CC number (channel 1). | 102 |
| **ADV** (bottom left) | Shows the slots, WRITE and LOCK. Off: a simpler view with room for longer values. Only the view changes – mapped slot buttons keep working. | off |
| **LC** (ADV) | Last click: the roller follows your clicks. | active |
| **2**–**10** (ADV) | Stored parameters: the roller stays on one until you press another slot, LC or click a parameter. | empty |
| **WRITE** (ADV) | Stores the last clicked parameter into the next slot 2–10 you press. | – |
| **LOCK** (ADV) | While a slot 2–10 is active, mouse clicks do not take the roller away from it. | off |

The sections below explain each of them.

## Use

Click a parameter in Live (a device knob, a track's volume or pan, a send…), then turn the roller. The status
bar at the bottom of Live shows `Click It! Track › Device › Parameter`, the device shows the parameter
and its value.

- **Window (HOLD off, default):** after a click you have 3 seconds (or Time, if longer) to start turning; Click It! then
  lets go **Time** (2 seconds by default) after your last roller step, and the roller goes back to its normal job (for example a
  keyswitch in the REMAPPER device). The roller on the device fades out as the time runs down.
- **HOLD on:** the roller stays on the last clicked parameter until you click another one or switch Click
  It! off.
- **ACC (on by default):** turning fast moves a parameter by up to 6 steps per roller step, turning slowly
  moves it exactly one step. Lists and switches with several positions always move one position per step.
- **S (Sensitivity):** the number of roller steps across a parameter's full range, from 1024 (fine) to 16
  (coarse). Drag it up or down.
- **CC:** the CC number of the roller (102).
- **On/off:** the device's on/off button. Map it to a key (Key Map mode) – or to a long press of a Feel
  Fader button that sends that key – to flip between Click It! and the roller's normal job. If several
  Click It! devices are in a set, any one switched off turns Click It! off. Without the device Click It!
  is always on, with the window, ACC on, 128 steps, on CC 102.

Each turn of the roller is one undo step (very fast spins can take two).

## Slots

Switch **ADV** on to see them. The strip next to the roller holds ten slots: **LC** (last click – the roller follows your clicks, as above)
and **2**–**10** for stored parameters.

- **Store:** click a parameter, press **WRITE** (it turns red, the slots blink), then press a slot 2–10.
  Pressing WRITE again cancels. The status bar shows `Click It! Parameter → slot N`. Press WRITE
  briefly: on a controller button that sends a CC, holding it longer than half a second cancels WRITE
  again when you let go.
- **Recall:** press a stored slot. The roller now moves that parameter, without a time limit, until you
  press another slot, press **LC** or click a parameter.
- **LOCK:** while a slot 2–10 is active, a click on another parameter does not take the roller away from
  it. The click is still remembered, so you can store it with WRITE.
- **LC:** back to following your clicks; the roller waits for your next click.
- **Controller buttons:** each slot button, WRITE and LOCK can be MIDI-mapped (MIDI Map mode) or key-mapped
  (Key Map mode) like any other control in Live; buttons sending notes or CCs both work. LOCK is an on/off
  switch: set its controller button to **toggle** mode, a momentary button keeps LOCK on only while held.
  On a Launchpad, map and use the slots in a User mode; in Session mode the pads belong to the Launchpad.
- **Controller lights:** Live lights a mapped button by that button's own on/off state, which does not
  follow the active slot (a slot you left can stay lit). The device shows the active slot, so switch the
  lights off: **Settings → Link, Tempo & MIDI → MIDI Ports**, turn off **Remote** for your controller's
  **output**. This turns off the lights of all your MIDI mappings on that controller.
- Click It! ignores button changes made by automation, a clip envelope or Undo, so none of them switches
  slots. Do not automate the buttons.

Slots are saved with the set. Pressing the buttons marks the set as changed, so Live reminds you to save
after storing slots. While the script runs, slots follow their tracks
and devices when you move or rename them, and the set saves where they are now. When you open a set that
was changed without the script (another computer, script not installed), Click It! looks for each stored
parameter by its track, device and parameter name; the ones it cannot find are reported once in the status
bar (`Click It! N slots not found`) and the slot is empty.
A slot whose device or track you delete empties itself.

The device shows **Script off** with the Settings path when the script is not running (step 2 or 3 above).

## Typical uses

- **A quick tweak of anything:** click, turn the roller, and 2 seconds later the roller is back on your
  keyswitches.
- **Parameters you come back to** (a filter, a send, a choir's volume): store them once with WRITE, then
  switch between them with controller buttons.
- **Keep the roller on one parameter while you play:** press its slot and switch LOCK on – mouse clicks
  will not take the roller away.

## Good to know

- Only clicks in Live's own interface count. Clicks inside a plugin's window do not – use the plugin's
  parameters in Live's device panel instead (**Configure** in the device title bar).
- Switches (device on/off, track on/off) and Song Tempo are ignored; the status bar says "not supported".
- Clicking the **same** track volume, pan or send (or a rack chain's volume or pan) again after Click It!
  has let go does nothing – Live does not report a second click on a mixer parameter that is still
  selected. Click anywhere else first, then click it again. Device parameters do not have this limit.
- When you switch Click It! on or open a set, the parameter that is already selected is not taken over –
  click elsewhere first, then click it.
- On playback, turning the roller on an automated parameter overrides the automation like moving it with
  the mouse; **Re-Enable Automation** brings the automation back.
