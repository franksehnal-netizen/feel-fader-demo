# FeelFader_ClickIt (Click It!, formerly Last Click): click a parameter in Live,
# turn the Feel Fader roller to move it. See
# docs/superpowers/specs/2026-10-26-last-click-v1-design.md.


def create_instance(c_instance):
    # Imported here so the package (and core.py) stays importable outside Live.
    from .surface import LastClickSurface
    return LastClickSurface(c_instance)
