# Live glue for Last Click: listeners, MIDI map, status bar, UDP to the LAST CLICK
# device and the slots stored with the set. The decisions live in core.py and
# slots.py; this file only feeds them events and carries out their effects.
import sys
import time
import traceback

import Live
from _Framework.ControlSurface import ControlSurface

from . import core, net, persist, slots

LOG_PREFIX = "FF ClickIt: "
SETTING_NAMES = ("Hold", "Accel", "Sensitivity", "CC in", "Lock", "Time")
# The device's momentary buttons: slot number, or WRITE.
BUTTONS = dict([("Slot LC", slots.LC), ("Write", "write")]
               + [("Slot %d" % n, n) for n in range(slots.FIRST, slots.LAST + 1)])
HEARTBEAT_S = 1.0       # full state to the device this often


class SetDataStore(object):
    """Slot descriptors saved in the set itself (Song.set_data, no undo step)."""

    def __init__(self, song):
        self._song = song

    def load(self):
        return self._song.get_data(persist.KEY, None)

    def save(self, text):
        self._song.set_data(persist.KEY, text)


class LastClickSurface(ControlSurface):
    def __init__(self, c_instance, link_factory=net.UdpLink):
        # Set before the base init: it may already ask for a MIDI map.
        self._core = core.LastClickCore()
        self._bank = slots.SlotBank(self._core)
        self._settings = core.merge_settings([])
        self._accel = core.Accelerator()
        self._devices = []
        self._pending = []
        self._presses = []  # button presses waiting for update_display
        self._unresolved = {}  # slot -> descriptor not found in the set (yet)
        self._loaded = False
        self._sent = {}
        self._saved_text = None
        self._last_beat = None
        self._last_refresh = None
        self._seen_errors = set()
        self._observed_tracks = []
        self._observed_devices = []
        self._watched = []
        self._buttons = []  # (parameter, its value listener)
        # (device index, button name) -> PressFilter; kept across rescans so a
        # release right after a rescan is still matched to its press.
        self._press_filters = {}
        self._rescan_needed = False
        self._settings_dirty = False
        ControlSurface.__init__(self, c_instance)
        self._link = link_factory(self._log)
        song = self.song()
        self._store = SetDataStore(song)
        song.view.add_selected_parameter_listener(self._on_selected_parameter)
        song.add_tracks_listener(self._on_structure_changed)
        song.add_return_tracks_listener(self._on_structure_changed)
        self._log("loaded")
        self._rescan(time.perf_counter())

    def disconnect(self):
        try:
            self._core.drop()
            song = self.song()
            if song.view.selected_parameter_has_listener(self._on_selected_parameter):
                song.view.remove_selected_parameter_listener(self._on_selected_parameter)
            if song.tracks_has_listener(self._on_structure_changed):
                song.remove_tracks_listener(self._on_structure_changed)
            if song.return_tracks_has_listener(self._on_structure_changed):
                song.remove_return_tracks_listener(self._on_structure_changed)
            self._unobserve()
            self._log("disconnected")
        except Exception:
            self._error("disconnect")
        finally:
            self._link.close()
        ControlSurface.disconnect(self)

    # ---- events from Live ----

    def _on_selected_parameter(self):
        try:
            p = self.song().view.selected_parameter
            if p is None:  # click outside a parameter, or our own selection reset
                return
            info = self._param_info(p)
            if info.is_own:  # slot buttons, WRITE, LOCK, pills: no message
                return
            supported = core.is_supported(info)
            self._queue(self._bank.click(p, supported, time.perf_counter()))
            if supported and self._core.enabled and self._bank.active == slots.LC:
                self.show_message("Click It! " + self._describe(p))
        except Exception:
            self._error("selected parameter")

    def receive_midi(self, midi_bytes):
        if (len(midi_bytes) == 3 and midi_bytes[0] == (0xB0 | core.CHANNEL)
                and midi_bytes[1] == self._settings.cc):
            self._on_tick(midi_bytes[2])
            return
        ControlSurface.receive_midi(self, midi_bytes)

    def _on_tick(self, value):
        try:
            direction = core.tick_direction(value)
            if direction == 0:
                return
            now = time.perf_counter()
            p = self._core.tick(now)
            if p is None:
                return
            # The accelerator sees every continuous tick, so its gap stays true.
            factor = 1.0
            if self._settings.accel and not p.is_quantized:
                factor = self._accel.factor(direction, now)
            p.value = core.next_value(p.value, p.min, p.max, p.is_quantized,
                                      direction, self._settings.steps, factor)
            self._link.send("/lc/tick", direction, _value_text(p))
        except Exception:
            self._error("tick")
            self._recover()

    def _on_structure_changed(self):
        # Listeners are rewired in update_display, not inside a notification.
        self._rescan_needed = True

    def _on_setting_changed(self):
        self._settings_dirty = True

    def _button_listener(self, p, button, key):
        pressed = self._press_filters.setdefault(key, slots.PressFilter())

        def on_value():
            # Read only; the press runs in update_display. A change made by Undo
            # leaves Redo available, a real press clears it (spike 1b).
            try:
                if self.song().can_redo or p.automation_state != 0:
                    return
                if pressed.is_press(p.value, time.perf_counter()):
                    self._presses.append(button)
            except Exception:
                self._error("button")
        return on_value

    # Called by Live about every 100 ms.
    def update_display(self):
        ControlSurface.update_display(self)
        try:
            now = time.perf_counter()
            if not self._loaded:
                self._loaded = True
                self._load_slots()
            # Listener effects first, so an ON/OFF message below is the one left
            # in the status bar.
            self._run_effects()
            if self._rescan_needed:
                self._rescan_needed = False
                self._settings_dirty = False
                self._rescan(now)
            elif self._settings_dirty:
                self._settings_dirty = False
                self._apply_settings(now, False)
            self._run_presses(now)
            self._check_targets()
            self._check_device(now)
            self._queue(self._core.poll(now))
            self._run_effects()
            if self._last_refresh is None or now - self._last_refresh >= HEARTBEAT_S:
                self._last_refresh = now
                self._save_slots()
            self._send_state(now)
        except Exception:
            self._error("update")
            self._recover()

    def build_midi_map(self, midi_map_handle):
        ControlSurface.build_midi_map(self, midi_map_handle)
        try:
            if self._core.grabbed:
                Live.MidiMap.forward_midi_cc(self._c_instance.handle(), midi_map_handle,
                                             core.CHANNEL, self._settings.cc)
        except Exception:
            self._error("midi map")

    # ---- the LAST CLICK device: buttons in, state out over UDP ----

    def _run_presses(self, now):
        presses, self._presses = self._presses, []
        for button in presses:
            if button == "write":
                self._queue(self._bank.write_press())
            else:
                self._press(button, now)

    def _press(self, n, now):
        bank = self._bank
        if bank.write_mode and self._core.enabled and slots.FIRST <= n <= slots.LAST:
            if persist.describe(self.song(), bank.last_click) is None:
                bank.write_mode = False
                self.show_message("Click It! %s can't be stored" % bank.last_click.name)
                return
            self._unresolved.pop(n, None)  # WRITE replaces a slot not found at load
        self._queue(bank.press(n, now))

    def _check_device(self, now):
        # Without the device there is no way to press LC or switch LOCK off.
        if self._devices:
            return
        bank = self._bank
        bank.write_mode = False
        bank.set_lock(False)
        if bank.active != slots.LC:
            self._log("LAST CLICK device gone, slot %d released" % bank.active)
            self._queue(bank.press(slots.LC, now))

    def _send_state(self, now):
        state = self._core.state
        if state == core.SLOT:
            state = core.HOLD  # the device draws a slot like Hold: no window
        p = self._core.target
        param = device = value = ""
        if p is not None:
            param, device, value = p.name, self._owner_label(p), _value_text(p)
        active = "LC" if self._bank.active == slots.LC else str(self._bank.active)
        stored = tuple(1 if self._bank.slots[n] is not None else 0
                       for n in range(slots.FIRST, slots.LAST + 1))
        parts = (("/lc/state", (state,)),
                 ("/lc/target", (active, param, device, value)),
                 ("/lc/slots", stored + (int(self._bank.write_mode),)))
        beat = self._last_beat is None or now - self._last_beat >= HEARTBEAT_S
        if beat:
            self._last_beat = now
        for address, args in parts:
            if beat or self._sent.get(address) != args:
                self._sent[address] = args
                if address == "/lc/state":
                    args = args + (self._core.remaining_ms(now), self._core.window_ms())
                self._link.send(address, *args)

    # ---- slots stored with the set ----

    def _load_slots(self):
        text = self._store.load()
        self._saved_text = text or persist.dumps(self.song(), {}, {})
        if not text:
            return
        found, self._unresolved = persist.loads(self.song(), text)
        self._bank.load(found)
        self._log("slots loaded: %d, not found: %d" % (len(found), len(self._unresolved)))
        if self._unresolved:
            self.show_message("Click It! %d slots not found" % len(self._unresolved))

    def _resolve_pending(self):
        song = self.song()
        for n, desc in list(self._unresolved.items()):
            p = persist.resolve(song, desc)
            if p is not None:
                self._bank.slots[n] = p
                del self._unresolved[n]
                self._log("slot %d found" % n)

    def _save_slots(self):
        # Also every heartbeat: Live renumbers auto-named tracks ("3-Audio") and
        # indexes shift, so a saved descriptor could match another track.
        text = persist.dumps(self.song(), self._bank.slots, self._unresolved)
        if text != self._saved_text:
            self._store.save(text)
            self._saved_text = text

    def _check_targets(self):
        bank = self._bank
        dead = []
        for p in [bank.last_click] + list(bank.slots.values()):
            if p is not None and not _alive(p) and p not in dead:
                dead.append(p)
        for p in dead:
            self._queue(bank.target_gone(p))
        if self._core.grabbed and not _alive(self._core.target):
            self._log("target gone")
            self._queue(self._core.drop())

    # ---- effects from the core and the slot bank ----

    def _queue(self, effects):
        self._pending.extend(effects)

    def _run_effects(self):
        effects, self._pending = self._pending, []
        for kind, target in effects:
            # One failing effect must not lose the ones after it (a release).
            try:
                self._run_effect(kind, target)
            except Exception:
                self._error("effect " + kind)

    def _run_effect(self, kind, target):
        if kind == "grab":
            self._c_instance.request_rebuild_midi_map()
            self._log("grab: " + self._describe(target))
        elif kind == "release":
            try:
                self._c_instance.request_rebuild_midi_map()
            finally:
                if target is not None:
                    self._reset_selection(target)
                else:
                    self._log("release")
        elif kind == "reset":
            self._reset_selection(target)
        elif kind == "unsupported":
            self.show_message("Click It! %s not supported" % target.name)
        elif kind == "slot_on":
            n, p = target
            self.show_message("Click It! slot %d \u203a %s" % (n, self._describe(p)))
        elif kind == "stored":
            n, p = target
            self.show_message("Click It! %s \u2192 slot %d" % (p.name, n))
        elif kind == "message":
            self.show_message(target)
        elif kind == "slots_changed":
            self._save_slots()

    def _recover(self):
        # Back to LC with nothing grabbed (spec 5.8), so an error tied to a slot
        # does not repeat every update; the MIDI map is rebuilt in any case.
        self._queue(self._bank.reset())
        self._run_effects()
        self._c_instance.request_rebuild_midi_map()

    def _reset_selection(self, p):
        # Live fires selected_parameter only when the selection changes, so a
        # second click on the same parameter needs the selection cleared first.
        # Skipped when another track is selected, or select_device would jump
        # back. (A click on a parameter does not select its device, so the
        # selected device cannot be part of the check.) Mixer parameters have
        # no device to select: select_device rejects MixerDevice, and selecting
        # another device leaves the mixer parameter selected (Live 12.3.5).
        try:
            song = self.song()
            owner = p.canonical_parent
            if _is_mixer(owner):
                self._log("release, selection reset not possible for mixer")
                return
            track = _owning_track(owner)
            if track is None or song.view.selected_track != track:
                self._log("release, selection reset skipped (view moved)")
                return
            song.view.select_device(owner)
            self._log("release, selection reset")
        except Exception:
            self._error("selection reset")

    # ---- LAST CLICK devices and settings ----

    def _rescan(self, now):
        self._unobserve()
        song = self.song()
        for track in list(song.tracks) + list(song.return_tracks) + [song.master_track]:
            track.add_devices_listener(self._on_structure_changed)
            self._observed_tracks.append(track)
        for device in core.iter_devices(song):
            # A Max device just dropped into the set gets its parameters a bit
            # later; its marker is only visible after that.
            if core.is_max_device(device):
                device.add_parameters_listener(self._on_structure_changed)
                self._observed_devices.append(device)
        self._devices = core.find_marked_devices(song)
        for index, device in enumerate(self._devices):
            # Live returns a new wrapper per access, so Device On goes by index.
            for i, p in enumerate(device.parameters):
                if i == 0 or p.name in SETTING_NAMES:
                    p.add_value_listener(self._on_setting_changed)
                    self._watched.append(p)
                elif p.name in BUTTONS:
                    listener = self._button_listener(p, BUTTONS[p.name], (index, p.name))
                    p.add_value_listener(listener)
                    self._buttons.append((p, listener))
        self._log("scan: %d LAST CLICK device(s)" % len(self._devices))
        self._resolve_pending()
        self._apply_settings(now, True)

    def _unobserve(self):
        for track in self._observed_tracks:
            try:
                if track.devices_has_listener(self._on_structure_changed):
                    track.remove_devices_listener(self._on_structure_changed)
            except Exception:
                pass  # track already deleted
        for device in self._observed_devices:
            try:
                if device.parameters_has_listener(self._on_structure_changed):
                    device.remove_parameters_listener(self._on_structure_changed)
            except Exception:
                pass  # device already deleted
        for p in self._watched:
            try:
                if p.value_has_listener(self._on_setting_changed):
                    p.remove_value_listener(self._on_setting_changed)
            except Exception:
                pass  # device already deleted
        for p, listener in self._buttons:
            try:
                if p.value_has_listener(listener):
                    p.remove_value_listener(listener)
            except Exception:
                pass  # device already deleted
        self._observed_tracks = []
        self._observed_devices = []
        self._watched = []
        self._buttons = []

    def _apply_settings(self, now, announce_conflict):
        old = self._settings
        new = core.merge_settings([_instance_settings(d) for d in self._devices])
        self._settings = new
        self._bank.set_lock(new.lock)
        if new.enabled != old.enabled:
            self.show_message("Click It! ON" if new.enabled else "Click It! OFF")
            self._log("ON" if new.enabled else "OFF")
            if not new.enabled:
                self._bank.switched_off()
        elif new.conflict and (announce_conflict or not old.conflict):
            self.show_message("Click It! devices differ, using the first one")
        self._queue(self._core.set_mode(new.enabled, new.hold, now, new.window))
        if new.cc != old.cc:
            self._c_instance.request_rebuild_midi_map()

    # ---- helpers ----

    def _param_info(self, p):
        owner = p.canonical_parent
        song = self.song()
        return core.ParamInfo(
            is_own=core.is_marked(owner),
            is_quantized=p.is_quantized, vmin=p.min, vmax=p.max,
            is_enabled=p.is_enabled,
            is_tempo=p == song.master_track.mixer_device.song_tempo)

    def _describe(self, p):
        owner = p.canonical_parent
        if _is_mixer(owner):
            track, device = owner.canonical_parent, "Mixer"
        else:
            track, device = _owning_track(owner), owner.name
        return "%s \u203a %s \u203a %s" % (track.name if track is not None else "?",
                                          device, p.name)

    def _owner_label(self, p):
        # The device shows the track name for mixer parameters (spec 5.6).
        owner = p.canonical_parent
        if _is_mixer(owner):
            return owner.canonical_parent.name
        return owner.name

    def _error(self, where):
        exc = sys.exc_info()[0]
        key = (where, exc.__name__ if exc else "")
        if key in self._seen_errors:
            return
        self._seen_errors.add(key)
        self._log("ERROR in %s:\n%s" % (where, traceback.format_exc()))

    def _log(self, text):
        self.log_message(LOG_PREFIX + text)


def _alive(p):
    try:
        return p is not None and p.canonical_parent is not None
    except Exception:
        return False


def _value_text(p):
    try:
        return p.str_for_value(p.value)
    except Exception:
        return u"\u2013"


def _is_mixer(obj):
    # Track mixer or a rack chain's mixer (chain volume, pan, sends).
    return type(obj).__name__ in ("MixerDevice", "ChainMixerDevice")


def _owning_track(obj):
    for _ in range(12):  # device -> chain -> rack -> ... -> track
        if obj is None or type(obj).__name__ == "Track":
            return obj
        obj = obj.canonical_parent
    return None


def _instance_settings(device):
    params = dict((p.name, p) for p in device.parameters)

    def value(name, default):
        p = params.get(name)
        return p.value if p is not None else default

    return core.InstanceSettings(
        on=device.parameters[0].value >= 0.5,  # Device On is always first
        hold=value("Hold", 0.0) >= 0.5,
        accel=value("Accel", 1.0) >= 0.5,
        sensitivity=value("Sensitivity", core.DEFAULT_SENSITIVITY),
        cc=value("CC in", core.DEFAULT_CC),
        lock=value("Lock", 0.0) >= 0.5,
        window=value("Time", core.WINDOW_S * 1000.0) / 1000.0)  # the device shows ms as s
