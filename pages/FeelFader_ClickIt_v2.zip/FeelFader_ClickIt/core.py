# Last Click core: plain Python, no `import Live`, so it runs under pytest.
from collections import namedtuple

FIRST_TOUCH_S = 3.0   # after a click: at least this long to reach the roller
WINDOW_S = 2.0        # release this long after the last roller tick (device "Time")
WINDOW_MIN_S = 0.5
WINDOW_MAX_S = 10.0
CHANNEL = 0           # MIDI channel 1
DEFAULT_CC = 102
DEFAULT_SENSITIVITY = 50.0
MARKER_NAME = "FF Marker"

FINEST_STEPS = 1024   # Sensitivity 0 %
COARSEST_STEPS = 16   # Sensitivity 100 %

# Acceleration by the gap between roller ticks (first guesses, tuned on the FF).
ACCEL_SLOW_S = 0.060  # this gap or more: plain step
ACCEL_FAST_S = 0.004  # this gap or less: ACCEL_MAX steps (firmware bursts)
ACCEL_MAX = 6.0

ParamInfo = namedtuple("ParamInfo", "is_own is_quantized vmin vmax is_enabled is_tempo")
InstanceSettings = namedtuple("InstanceSettings", "on hold accel sensitivity cc lock window",
                              defaults=(False, WINDOW_S))
Settings = namedtuple("Settings", "enabled hold accel steps cc conflict lock window",
                      defaults=(False, WINDOW_S))


def clamp_window(seconds):
    return max(WINDOW_MIN_S, min(WINDOW_MAX_S, float(seconds)))


def steps_for_sensitivity(sensitivity):
    """Roller steps across a continuous parameter's full range (log scale)."""
    s = max(0.0, min(100.0, float(sensitivity)))
    return int(round(FINEST_STEPS * (float(COARSEST_STEPS) / FINEST_STEPS) ** (s / 100.0)))


def tick_direction(cc_value):
    """Relative CC from the roller: 1 = one step up, 127 = one step down."""
    if cc_value == 1:
        return 1
    if cc_value == 127:
        return -1
    return 0


def next_value(value, vmin, vmax, quantized, direction, steps, factor=1.0):
    if quantized:
        new = value + direction
    else:
        new = value + direction * factor * (vmax - vmin) / float(steps)
    return max(vmin, min(vmax, new))


class Accelerator(object):
    """Step multiplier from the gap to the previous tick in the same direction."""

    def __init__(self):
        self._last = None
        self._direction = 0

    def factor(self, direction, now):
        last, same = self._last, direction == self._direction
        self._last, self._direction = now, direction
        if last is None or not same:
            return 1.0
        gap = now - last
        if gap >= ACCEL_SLOW_S:
            return 1.0
        if gap <= ACCEL_FAST_S:
            return ACCEL_MAX
        return 1.0 + (ACCEL_MAX - 1.0) * (ACCEL_SLOW_S - gap) / (ACCEL_SLOW_S - ACCEL_FAST_S)


def is_supported(info):
    # Two-state toggles (Device On, track activator) and Song Tempo make no
    # sense on a roller; our own device's parameters are its settings.
    if info.is_own or info.is_tempo or not info.is_enabled:
        return False
    if info.is_quantized and info.vmax - info.vmin <= 1:
        return False
    return True


def merge_settings(instances):
    """Any instance OFF switches Last Click off; settings come from the first."""
    if not instances:
        return Settings(True, False, True, steps_for_sensitivity(DEFAULT_SENSITIVITY),
                        DEFAULT_CC, False)
    first = instances[0]
    key = lambda i: (bool(i.hold), bool(i.accel), i.sensitivity, i.cc, bool(i.lock), i.window)
    conflict = any(key(i) != key(first) for i in instances[1:])
    return Settings(enabled=all(i.on for i in instances),
                    hold=bool(first.hold),
                    accel=bool(first.accel),
                    steps=steps_for_sensitivity(first.sensitivity),
                    cc=int(round(first.cc)),
                    conflict=conflict,
                    lock=bool(first.lock),
                    window=clamp_window(first.window))


def is_max_device(device):
    return getattr(device, "class_name", "").startswith("Mx")


def is_marked(device):
    # Only Max for Live devices: a plugin parameter could share the name.
    return is_max_device(device) and any(p.name == MARKER_NAME for p in device.parameters)


def find_marked_devices(song):
    """LAST CLICK devices in set order: tracks, return tracks, Main; racks depth-first."""
    return [d for d in iter_devices(song) if is_marked(d)]


def iter_devices(song):
    tracks = list(song.tracks) + list(song.return_tracks) + [song.master_track]
    for track in tracks:
        for device in track.devices:
            for d in _walk(device):
                yield d


def _walk(device):
    yield device
    if getattr(device, "can_have_chains", False):
        # Drum racks keep their return chains apart from the pad chains.
        for chain in list(device.chains) + list(getattr(device, "return_chains", [])):
            for d in chain.devices:
                for inner in _walk(d):
                    yield inner


IDLE, WAITING, ACTIVE, HOLD, SLOT = "idle", "waiting", "active", "hold", "slot"


class LastClickCore(object):
    """Grab window state machine.

    Methods return a list of effects for the Live glue:
    ("grab", target)        forward the roller CC to the script
    ("release", target)     stop forwarding; with a target, also reset Live's
                            selection so the next click on it fires again;
                            None = release without reset
    ("unsupported", target) status bar message only
    WAITING lasts first_touch (FIRST_TOUCH_S or the window, the longer) after a
    click, ACTIVE the window (device "Time") after the last tick; HOLD (Hold on)
    keeps the target until Last Click is switched off.
    SLOT holds a stored slot's target with no timer, whatever Hold says.
    ("reset", target)       a slot took over from a clicked target: reset Live's
                            selection, the CC stays forwarded
    """

    def __init__(self, enabled=True, hold=False, window=WINDOW_S):
        self.enabled = enabled
        self.hold = hold
        self.window = window
        self.state = IDLE
        self.target = None
        self._deadline = 0.0

    @property
    def grabbed(self):
        return self.state != IDLE

    @property
    def first_touch(self):
        return max(FIRST_TOUCH_S, self.window)

    def select(self, target, supported, now):
        if not self.enabled:
            return []
        if not supported:
            return [("unsupported", target)]
        effects = [] if self.grabbed else [("grab", target)]
        self.target = target
        if self.hold:
            self.state = HOLD
        else:
            self.state = WAITING
            self._deadline = now + self.first_touch
        return effects

    def tick(self, now):
        if not self.grabbed:
            return None
        if self.state in (WAITING, ACTIVE):
            self.state = ACTIVE
            self._deadline = now + self.window
        return self.target

    def poll(self, now):
        if self.state in (WAITING, ACTIVE) and now > self._deadline:
            return self._release(self.target)
        return []

    def remaining_ms(self, now):
        """Time left in the grab window; 0 outside WAITING/ACTIVE."""
        if self.state not in (WAITING, ACTIVE):
            return 0
        return max(0, int(round((self._deadline - now) * 1000)))

    def window_ms(self):
        """Full length of the running window, for the device's fade; 0 outside it."""
        if self.state == WAITING:
            return int(round(self.first_touch * 1000))
        if self.state == ACTIVE:
            return int(round(self.window * 1000))
        return 0

    def set_mode(self, enabled, hold, now, window=None):
        """A changed window applies from the next click or tick."""
        self.enabled = enabled
        self.hold = hold
        if window is not None:
            self.window = window
        if not self.grabbed:
            return []
        if not enabled:
            return self._release(None if self.state == SLOT else self.target)
        if self.state == SLOT:
            return []
        if not hold and self.state == HOLD:
            self.state = ACTIVE
            self._deadline = now + self.window
        elif hold and self.state != HOLD:
            self.state = HOLD
        return []

    def take(self, target):
        """A slot takes the roller: permanently, no window."""
        if self.state == IDLE:
            effects = [("grab", target)]
        elif self.state == SLOT:
            effects = []
        else:
            effects = [("reset", self.target)]
        self.state = SLOT
        self.target = target
        return effects

    def free(self):
        """Back to idle without touching Live's selection."""
        return self.drop()

    def drop(self):
        if not self.grabbed:
            return []
        return self._release(None)

    def _release(self, reset_target):
        self.state = IDLE
        self.target = None
        return [("release", reset_target)]
