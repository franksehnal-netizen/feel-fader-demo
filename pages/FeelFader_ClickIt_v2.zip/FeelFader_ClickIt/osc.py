# Minimal OSC 1.0 messages (int, float, string) for Max [udpreceive]/[udpsend].
# Plain Python, no sockets, so it runs under pytest.
import struct

EMPTY = u"–"  # Max drops an empty OSC string, so empty text travels as a dash


def encode(address, *args):
    tags, payload = ",", b""
    for arg in args:
        if isinstance(arg, int):  # bool too
            tags += "i"
            payload += struct.pack(">i", int(arg))
        elif isinstance(arg, float):
            tags += "f"
            payload += struct.pack(">f", arg)
        else:
            tags += "s"
            payload += _string(arg or EMPTY)
    return _string(address) + _string(tags) + payload


def decode(data):
    """(address, args); ValueError when data is not an OSC message we understand."""
    try:
        address, i = _read_string(data, 0)
        tags, i = _read_string(data, i)
        if not address.startswith("/") or not tags.startswith(","):
            raise ValueError("not an OSC message")
        args = []
        for tag in tags[1:]:
            if tag in "if":
                if i + 4 > len(data):
                    raise ValueError("truncated argument")
                args.append(struct.unpack(">" + tag, data[i:i + 4])[0])
                i += 4
            elif tag == "s":
                text, i = _read_string(data, i)
                args.append(text)
            else:
                raise ValueError("unsupported OSC type " + tag)
        return address, args
    except (UnicodeDecodeError, struct.error) as e:
        raise ValueError(str(e))


def _string(text):
    raw = text.encode("utf-8") + b"\0"
    return raw + b"\0" * (-len(raw) % 4)


def _read_string(data, start):
    end = data.find(b"\0", start)
    if end < 0:
        raise ValueError("unterminated string")
    text = data[start:end].decode("utf-8")
    return text, end + 1 + (-(end + 1 - start) % 4)
