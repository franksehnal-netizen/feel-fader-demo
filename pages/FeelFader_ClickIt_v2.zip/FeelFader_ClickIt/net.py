# Localhost UDP from the script to the LAST CLICK device: state for its display.
# Fire and forget: a socket error is logged once per kind and Last Click runs on.
import socket

from . import osc

HOST = "127.0.0.1"
TO_DEVICE = 47816   # script -> device [udpreceive]


class UdpLink(object):
    def __init__(self, log, socket_factory=socket.socket):
        self._log = log
        self._seen = set()
        self._tx = socket_factory(socket.AF_INET, socket.SOCK_DGRAM)
        self._tx.setblocking(False)

    def send(self, address, *args):
        try:
            self._tx.sendto(osc.encode(address, *args), (HOST, TO_DEVICE))
        except ConnectionResetError:
            pass  # Windows: ICMP for an earlier datagram nobody received
        except Exception as e:
            self._once("send", e)

    def close(self):
        try:
            self._tx.close()
        except Exception:
            pass

    def _once(self, where, error):
        key = (where, type(error).__name__)
        if key not in self._seen:
            self._seen.add(key)
            self._log("UDP %s failed: %r" % (where, error))
