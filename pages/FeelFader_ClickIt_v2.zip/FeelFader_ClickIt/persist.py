# Slot descriptors: a Live parameter <-> a JSON-safe path from its track, plus the
# names that check it. Plain Python, no `import Live`, so it runs under pytest.
import json

from . import core

KEY = "ff_lastclick_slots"
SLOT_NUMBERS = range(2, 11)
MAX_DEPTH = 16
# Parent attributes that hold a child: one object, or a list (child = index).
SINGLE_ATTRS = ("mixer_device", "volume", "panning", "cue_volume")
LIST_ATTRS = ("sends", "parameters", "devices", "chains", "return_chains")


def describe(song, p):
    """{"track", "steps", "names"} for p, or None if p cannot be reached from a track."""
    try:
        steps, obj = [], p
        for _ in range(MAX_DEPTH):
            parent = obj.canonical_parent
            if parent is None:
                return None
            step = _step(parent, obj)
            if step is None:
                return None
            steps.insert(0, step)
            track = _track_ref(song, parent)
            if track is not None:
                return {"track": track, "steps": steps,
                        "names": [parent.name, _owner_name(p.canonical_parent, steps), p.name]}
            obj = parent
    except Exception:
        pass
    return None


def resolve(song, desc):
    """The parameter desc points at, else the first one in the set with its names."""
    names = list(desc["names"])
    try:
        attr, index = desc["track"]
        track = obj = _child(song, attr, index)
        for attr, index in desc["steps"]:
            owner, obj = obj, _child(obj, attr, index)
        if [track.name, _owner_name(owner, desc["steps"]), obj.name] == names:
            return obj
    except Exception:
        pass
    for track_name, owner_name, p in _all_params(song):
        if [track_name, owner_name, p.name] == names:
            return p
    return None


def dumps(song, slots, pending):
    """JSON for set_data: occupied slots described anew, unresolved ones kept as loaded."""
    out = dict((str(n), d) for n, d in pending.items())
    for n, p in slots.items():
        desc = describe(song, p) if p is not None else None
        if desc is not None:
            out[str(n)] = desc
    return json.dumps(out, sort_keys=True)


def loads(song, text):
    """(slots, pending): found parameters and the descriptors of the ones not found."""
    slots, pending = {}, {}
    try:
        data = json.loads(text)
    except Exception:
        return {}, {}
    if not isinstance(data, dict):
        return {}, {}
    for key, desc in data.items():
        try:
            n = int(key)
            if n not in SLOT_NUMBERS or not _valid(desc):
                continue
            p = resolve(song, desc)
            if p is not None:
                slots[n] = p
            else:
                pending[n] = desc
        except Exception:
            continue
    return slots, pending


def _valid(desc):
    return (isinstance(desc, dict)
            and isinstance(desc.get("track"), list) and len(desc["track"]) == 2
            and isinstance(desc.get("steps"), list)
            and all(isinstance(s, list) and len(s) == 2 for s in desc["steps"])
            and isinstance(desc.get("names"), list) and len(desc["names"]) == 3)


def _step(parent, obj):
    for attr in SINGLE_ATTRS:
        if _get(parent, attr) == obj:
            return [attr, None]
    for attr in LIST_ATTRS:
        for i, child in enumerate(_get(parent, attr) or []):
            if child == obj:
                return [attr, i]
    return None


def _get(obj, attr):
    try:
        return getattr(obj, attr, None)
    except Exception:
        return None


def _child(obj, attr, index):
    child = getattr(obj, attr)
    return child if index is None else list(child)[index]


def _track_ref(song, obj):
    for attr in ("tracks", "return_tracks"):
        for i, track in enumerate(getattr(song, attr)):
            if track == obj:
                return [attr, i]
    if song.master_track == obj:
        return ["master_track", None]
    return None


def _owner_name(owner, steps):
    # Mixer parameters show as "Mixer", the same as in the status bar.
    if len(steps) >= 2 and steps[-2][0] == "mixer_device":
        return "Mixer"
    return owner.name


def _all_params(song):
    """(track name, owner name, parameter): devices in set order, then the track mixers."""
    tracks = list(song.tracks) + list(song.return_tracks) + [song.master_track]
    for track in tracks:
        for device in track.devices:
            for d in core._walk(device):
                for p in d.parameters:
                    yield track.name, d.name, p
    for track in tracks:
        mixer = track.mixer_device
        for attr in ("volume", "panning", "cue_volume"):
            p = _get(mixer, attr)
            if p is not None:
                yield track.name, "Mixer", p
        for p in _get(mixer, "sends") or []:
            yield track.name, "Mixer", p
