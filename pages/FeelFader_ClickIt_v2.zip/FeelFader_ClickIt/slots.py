# Slots 1-10 around the Last Click core: LC (slot 1) follows clicks, slots 2-10
# hold stored parameters. Plain Python, no `import Live`, so it runs under pytest.
LC = 1
FIRST, LAST = 2, 10
PRESS_RELEASE_S = 0.5  # 1 -> 0 this soon after a counted press is its release


class PressFilter(object):
    """One button press = one press, whatever Live's MIDI Map does to the button.

    A note toggles the button on note-on, CC 127/0 holds it at 1 while pressed,
    the mouse gives 0 -> 1 and ~0.1 s later 1 -> 0 (spike 1b). So every change
    is a press, except a 1 -> 0 that quickly follows a counted 0 -> 1.
    """

    def __init__(self):
        self._pressed_at = None

    def is_press(self, value, now):
        if value >= 0.5:
            self._pressed_at = now
            return True
        pressed_at, self._pressed_at = self._pressed_at, None
        return pressed_at is None or now - pressed_at > PRESS_RELEASE_S


class SlotBank(object):
    """Slot presses, WRITE and LOCK on top of a LastClickCore.

    Methods return the core's effects plus:
    ("slot_on", (n, target))  slot n took the roller
    ("stored", (n, target))   WRITE put target into slot n
    ("message", text)         status bar text as is
    ("slots_changed", None)   the stored slots changed: save them with the set
    """

    def __init__(self, core):
        self.core = core
        self.active = LC
        self.slots = dict((n, None) for n in range(FIRST, LAST + 1))
        self.last_click = None
        self.write_mode = False
        self.lock = False

    def load(self, slots):
        self.slots = dict((n, slots.get(n)) for n in range(FIRST, LAST + 1))
        self.write_mode = False

    def click(self, target, supported, now):
        if not self.core.enabled:
            return []
        if not supported:
            return self.core.select(target, False, now)
        self.last_click = target
        if self.active != LC:
            if self.lock:
                return [("message", "Click It! locked to slot %d" % self.active)]
            self.active = LC
        return self.core.select(target, True, now)

    def press(self, n, now):
        if not self.core.enabled or not LC <= n <= LAST:
            return []
        if self.write_mode:
            return self._store(n)
        if n == self.active:
            return []
        if n == LC:
            self.active = LC
            return self.core.free()
        target = self.slots[n]
        if target is None:
            return [("message", "Click It! slot %d is empty" % n)]
        self.active = n
        return self.core.take(target) + [("slot_on", (n, target))]

    def write_press(self):
        if not self.core.enabled:
            return []
        if self.write_mode:
            self.write_mode = False
            return []
        if self.last_click is None:
            return [("message", "Click It! click a parameter first")]
        self.write_mode = True
        return []

    def set_lock(self, on):
        self.lock = bool(on)

    def target_gone(self, target):
        """target was deleted from the set: empty every slot that held it."""
        if self.last_click is not None and self.last_click == target:
            self.last_click = None
            self.write_mode = False
        emptied = [n for n in range(FIRST, LAST + 1)
                   if self.slots[n] is not None and self.slots[n] == target]
        if not emptied:
            return []
        effects = []
        for n in emptied:
            self.slots[n] = None
        if self.active in emptied:
            self.active = LC
            effects += self.core.free()
        effects.append(("slots_changed", None))
        effects += [("message", "Click It! slot %d target removed" % n) for n in emptied]
        return effects

    def switched_off(self):
        self.active = LC
        self.write_mode = False

    def reset(self):
        """After an error: back to LC with the core released."""
        self.switched_off()
        return self.core.drop()

    def _store(self, n):
        self.write_mode = False
        if n == LC:
            return [("message", "Click It! LC can't store")]
        target = self.last_click
        self.slots[n] = target
        effects = [("stored", (n, target)), ("slots_changed", None)]
        if n == self.active:
            # The roller follows what the slot now holds.
            effects = self.core.take(target) + effects
        return effects
